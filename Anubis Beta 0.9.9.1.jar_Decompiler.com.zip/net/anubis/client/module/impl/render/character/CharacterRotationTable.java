package net.anubis.client.module.impl.render.character;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
final class CharacterRotationTable {
   final float[] values = new float[153];
   private int lastPitch;
   private int lastYaw;
   private int lastRoll;
   private boolean ready;

   void update(float pitch, float yaw, float roll, boolean reuse) {
      int pitchBits = Float.floatToIntBits(pitch);
      int yawBits = Float.floatToIntBits(yaw);
      int rollBits = Float.floatToIntBits(roll);
      if (!reuse || !this.ready || pitchBits != this.lastPitch || yawBits != this.lastYaw || rollBits != this.lastRoll) {
         for(int k = 0; k <= 16; ++k) {
            float t = (float)k / 16.0F;
            float cx = (float)Math.cos((double)(pitch * t));
            float sx = (float)Math.sin((double)(pitch * t));
            float cy = (float)Math.cos((double)(yaw * t));
            float sy = (float)Math.sin((double)(yaw * t));
            float cz = (float)Math.cos((double)(roll * t));
            float sz = (float)Math.sin((double)(roll * t));
            int o = k * 9;
            this.values[o] = cz * cy;
            this.values[o + 1] = cz * sy * sx - sz * cx;
            this.values[o + 2] = cz * sy * cx + sz * sx;
            this.values[o + 3] = sz * cy;
            this.values[o + 4] = sz * sy * sx + cz * cx;
            this.values[o + 5] = sz * sy * cx - cz * sx;
            this.values[o + 6] = -sy;
            this.values[o + 7] = cy * sx;
            this.values[o + 8] = cy * cx;
         }

         this.lastPitch = pitchBits;
         this.lastYaw = yawBits;
         this.lastRoll = rollBits;
         this.ready = true;
      }
   }
}
