package net.anubis.client.module.impl.movement.elytrafly;

import net.anubis.client.chat.ModuleChat;
import net.anubis.client.event.impl.PlayerMoveEvent;
import net.anubis.client.module.impl.movement.ElytraFlyModule;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_746;

@Environment(EnvType.CLIENT)
public final class Pitch40Mode extends ElytraFlightMode {
   private static final int MIN_START_ABOVE_LOWER = 40;
   private boolean pitchingDown = true;
   private float pitch;

   public Pitch40Mode(ElytraFlyModule elytraFly) {
      super(elytraFly);
   }

   public void onActivate() {
      class_746 player = this.mc.field_1724;
      if (player.method_23318() < (double)this.elytraFly.pitch40upperBounds.get()) {
         ModuleChat.send(this.elytraFly, (ModuleChat.Body)ModuleChat.body().text("Pitch40 ").danger("can't start").text(", you must be above the upper bound (Y ").value(this.elytraFly.pitch40upperBounds.getInt()).text(")"));
         this.elytraFly.disableFromMode();
      } else if (player.method_23318() - (double)40.0F < (double)this.elytraFly.pitch40lowerBounds.get()) {
         ModuleChat.send(this.elytraFly, (ModuleChat.Body)ModuleChat.body().text("Pitch40 ").danger("can't start").text(", you must be at least ").value(40).text(" blocks above the lower bound (Y ").value(this.elytraFly.pitch40lowerBounds.getInt()).text(")"));
         this.elytraFly.disableFromMode();
      }

      this.pitch = 37.72F;
   }

   private float randPitch(float pitch, float bound) {
      return (float)((double)pitch + (double)bound * (Math.random() - (double)0.5F));
   }

   public void onTick() {
      super.onTick();
      class_746 player = this.mc.field_1724;
      if (player != null) {
         if (this.pitchingDown && player.method_23318() <= (double)this.elytraFly.pitch40lowerBounds.get()) {
            this.pitchingDown = false;
         } else if (!this.pitchingDown && player.method_23318() >= (double)this.elytraFly.pitch40upperBounds.get()) {
            this.pitchingDown = true;
         }

         if (!this.pitchingDown) {
            this.pitch -= this.randPitch(this.elytraFly.pitch40rotationSpeedUp.get(), 1.0F);
            if (this.pitch < -54.77F) {
               this.pitch = -54.77F;
               this.pitchingDown = true;
            }
         } else if (this.pitch < 37.72F) {
            this.pitch += this.randPitch(this.elytraFly.pitch40rotationSpeedDown.get(), 0.5F);
         }

         player.method_36457(this.pitch);
      }
   }

   public void autoTakeoff() {
   }

   public void handleHorizontalSpeed(PlayerMoveEvent event) {
      this.velX = event.x;
      this.velZ = event.z;
   }

   public void handleVerticalSpeed(PlayerMoveEvent event) {
   }

   public void handleFallMultiplier() {
   }

   public void handleAutopilot() {
   }
}
